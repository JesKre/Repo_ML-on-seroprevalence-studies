# ============================================================================
# LASSO_testset_moving_block_bootstrap.R
# ----------------------------------------------------------------------------
# 95% confidence intervals for the LASSO test-set error metrics RMSE and
# SMAPE, for both the MuSPAD LASSO model and the time-only baseline, by
# moving-block bootstrap (block length = 7 days) of the paired
# (observed, predicted) test values.
#
# The paired test values are taken from the exact saved predictions used for
# the paper's Tables 1-5 (no re-fitting):
#   Compare_models/Graphics/Predicted_values/LASSO_7day_MuSPAD.RData
#   Compare_models/Graphics/Predicted_values/LASSO_7day_baseline.RData
# so the CIs refer to the paper's published point estimates.
#
# Method (user-specified):
#   - test set: the held-out 10% block = 27 observations,
#     2021-07-16 .. 2021-08-23 (nearly consecutive days; one 8-day
#     reporting gap inside the block)
#   - moving-block bootstrap with block length b = 7, matching the 7-day
#     forecasting horizon; consecutive days are autocorrelated, so an IID
#     resample would understate the uncertainty of the test error
#   - K = ceiling(27/7) = 4 blocks per replicate; block start positions
#     drawn with replacement from the 21 possible positions; the 28
#     resampled observations are truncated back to 27
#   - B = 10000 replicates; per replicate RMSE and SMAPE are recomputed on
#     the resampled (real, predicted) pairs
#   - 95% CI = 2.5th / 97.5th percentile of the bootstrap distribution
#   - an IID (single-observation) bootstrap with identical B and seed is
#     reported alongside for comparison
#
# Outputs (written to LASSO/repro_results/):
#   bootstrap_ci_LASSO_testset.csv
#   LASSO_testset_moving_block_bootstrap_CIs.md
#   boot_samples_LASSO_testset.rda
# ============================================================================

suppressMessages(library(Metrics))

LASSO_DIR <- "S:/PROJACTIVE/MUSPAD-LABORERGEBNISSE/LOKI_ML/muspad-ml-loki-sp2.1/LASSO"
PV_DIR    <- "S:/PROJACTIVE/MUSPAD-LABORERGEBNISSE/LOKI_ML/muspad-ml-loki-sp2.1/Compare_models/Graphics/Predicted_values"
OUT_DIR   <- file.path(LASSO_DIR, "repro_results")
dir.create(OUT_DIR, showWarnings = FALSE, recursive = TRUE)

B     <- 10000
BLOCK <- 7
SEED  <- 42

models <- list(
  list(name = "MuSPAD",   file = "LASSO_7day_MuSPAD.RData",   obj = "graph_LASSO_7day_M"),
  list(name = "onlyTime", file = "LASSO_7day_baseline.RData", obj = "graph_LASSO_7day_BL"))

load_test_pairs <- function(m) {
  env <- new.env()
  load(file.path(PV_DIR, m$file), envir = env)
  d <- env[[m$obj]]
  x <- d[d[["set"]] == "Test", ]
  r <- x[x[["real_vs_pred"]] == "real", c("time", "Incidence")]
  p <- x[x[["real_vs_pred"]] == "predicted", c("time", "Incidence")]
  names(r)[2] <- "real"
  names(p)[2] <- "predicted"
  pairs <- merge(r, p, by = "time")
  pairs[order(pairs$time), , drop = FALSE]
}

# --- vectorised moving-block bootstrap index generator ------------------------
# n observations, block length b: K = ceiling(n/b) blocks per replicate,
# starts sampled with replacement from 1..(n-b+1), concatenated and
# truncated back to n observations.
moving_block_indices <- function(n, b, B, seed) {
  K         <- ceiling(n / b)
  max_start <- n - b + 1
  set.seed(seed)
  starts <- matrix(sample.int(max_start, size = B * K, replace = TRUE), nrow = B)
  # row i, block k, offset j  ->  idx[i, (k-1)*b + j] = starts[i, k] + (j-1)
  # (vapply on a matrix fails: its internal FUN(X[[1]]) check treats X[[1]]
  #  as the scalar element [1], not the first column)
  offs <- matrix(0:(b - 1), ncol = b, nrow = B, byrow = TRUE)
  idx  <- matrix(0L, nrow = B, ncol = K * b)
  for (k in seq_len(K))
    idx[, (k - 1) * b + seq_len(b)] <- starts[, k] + offs
  idx[, seq_len(n), drop = FALSE]
}

# --- IID (single-observation) bootstrap index generator -----------------------
iid_indices <- function(n, B, seed) {
  set.seed(seed)
  matrix(sample.int(n, size = B * n, replace = TRUE), nrow = B)
}

# --- RMSE / SMAPE on a B x n index matrix (Metrics-package definitions) -------
# Note: vector[matrix] in R returns a plain vector (column-major index order),
# so the indexed values are reshaped back to the B x n layout explicitly.
boot_metrics <- function(idx, real, pred) {
  Rm <- matrix(real[idx], nrow = NROW(idx))
  Pm <- matrix(pred[idx], nrow = NROW(idx))
  rmse_b  <- sqrt(rowMeans((Rm - Pm) ^ 2))
  smape_b <- rowMeans(2 * abs(Rm - Pm) / (abs(Rm) + abs(Pm)))
  list(rmse = rmse_b, smape = smape_b)
}

ci95 <- function(x) as.numeric(quantile(x, c(0.025, 0.975)))

results   <- list()
raw       <- list()
point_est <- list()
dates     <- list()
for (m in models) {
  pairs <- load_test_pairs(m)
  real  <- pairs$real
  pred  <- pairs$predicted
  n     <- length(real)
  dates[[m$name]] <- pairs$time

  pe <- c(rmse_test  = rmse(real, pred),
          smape_test = smape(real, pred))
  point_est[[m$name]] <- pe

  mb  <- boot_metrics(moving_block_indices(n, BLOCK, B, SEED), real, pred)
  iid <- boot_metrics(iid_indices(n, B, SEED), real, pred)

  raw[[m$name]] <- list(rmse_mb = mb$rmse,   smape_mb = mb$smape,
                        rmse_iid = iid$rmse, smape_iid = iid$smape)

  results[[m$name]] <- rbind(
    data.frame(model = m$name, metric = "RMSE",
               point_estimate = pe["rmse_test"],
               ci95_lo = ci95(mb$rmse)[1], ci95_hi = ci95(mb$rmse)[2],
               method = "moving_block", B = B, block_length = BLOCK, n_test = n),
    data.frame(model = m$name, metric = "SMAPE",
               point_estimate = pe["smape_test"],
               ci95_lo = ci95(mb$smape)[1], ci95_hi = ci95(mb$smape)[2],
               method = "moving_block", B = B, block_length = BLOCK, n_test = n),
    data.frame(model = m$name, metric = "RMSE",
               point_estimate = pe["rmse_test"],
               ci95_lo = ci95(iid$rmse)[1], ci95_hi = ci95(iid$rmse)[2],
               method = "iid", B = B, block_length = 1, n_test = n),
    data.frame(model = m$name, metric = "SMAPE",
               point_estimate = pe["smape_test"],
               ci95_lo = ci95(iid$smape)[1], ci95_hi = ci95(iid$smape)[2],
               method = "iid", B = B, block_length = 1, n_test = n))
  message(sprintf("[%s] n=%d  RMSE=%.4f  SMAPE=%.4f  done (moving-block + IID, B=%d)",
                  m$name, n, pe["rmse_test"], pe["smape_test"], B))
}

res <- do.call(rbind, results)
save(raw, file = file.path(OUT_DIR, "boot_samples_LASSO_testset.rda"))
write.csv(res, file.path(OUT_DIR, "bootstrap_ci_LASSO_testset.csv"), row.names = FALSE)

# --- markdown summary -----------------------------------------------------------
fmt <- function(x) formatC(x, format = "f", digits = 3)
n_test <- length(dates[["MuSPAD"]])

md <- c(
  "# LASSO test-set error: moving-block bootstrap 95% CIs (RMSE, SMAPE)",
  "",
  sprintf("Generated: %s", format(Sys.time(), "%Y-%m-%d %H:%M")),
  "",
  "Paired (observed, predicted) test values from the saved predictions behind the paper's Tables 1-5",
  "(`Compare_models/Graphics/Predicted_values/LASSO_7day_MuSPAD.RData` and `LASSO_7day_baseline.RData`).",
  "No re-fitting: the CIs refer to the paper's published point estimates.",
  "",
  sprintf("Test set: n = %d held-out observations, %s .. %s (nearly consecutive days; one 8-day reporting gap inside the block).",
          n_test, format(min(dates[["MuSPAD"]])), format(max(dates[["MuSPAD"]]))),
  "",
  "## Method",
  "",
  "- Moving-block bootstrap with block length b = 7, matching the 7-day forecasting horizon;",
  "  consecutive days are autocorrelated, so an IID resample understates the uncertainty of the test error.",
  sprintf("- Per replicate: K = ceiling(%d/7) = %d blocks; block start positions sampled with replacement from the %d possible positions; the %d resampled observations are truncated back to %d.",
          n_test, ceiling(n_test / BLOCK), n_test - BLOCK + 1, ceiling(n_test / BLOCK) * BLOCK, n_test),
  sprintf("- B = %d replicates; per replicate RMSE and SMAPE recomputed on the resampled (real, predicted) pairs.", B),
  "- 95% CI = 2.5th / 97.5th percentile of the bootstrap distribution.",
  sprintf("- Seed = %d. An IID (single-observation) bootstrap with the same B and seed is included for comparison.", SEED),
  "",
  "## Results",
  "",
  "| model | metric | point estimate | moving-block 95% CI | IID 95% CI (comparison) |",
  "|---|---|---|---|---|")
for (m in c("MuSPAD", "onlyTime")) {
  for (met in c("RMSE", "SMAPE")) {
    pm <- res[res$model == m & res$metric == met & res$method == "moving_block", ]
    pi2 <- res[res$model == m & res$metric == met & res$method == "iid", ]
    md <- c(md, sprintf("| %s | %s | %s | [%s, %s] | [%s, %s] |",
                        m, met, fmt(pm$point_estimate),
                        fmt(pm$ci95_lo), fmt(pm$ci95_hi),
                        fmt(pi2$ci95_lo), fmt(pi2$ci95_hi)))
  }
}
md <- c(md,
  "",
  "## Consistency checks",
  "",
  sprintf("- Point estimates reproduce the paper's Tables 3 and 5: MuSPAD RMSE %.2f / SMAPE %.2f; onlyTime RMSE %.2f / SMAPE %.2f.",
          point_est[["MuSPAD"]][["rmse_test"]],   point_est[["MuSPAD"]][["smape_test"]],
          point_est[["onlyTime"]][["rmse_test"]], point_est[["onlyTime"]][["smape_test"]]),
  "- The moving-block CIs are wider than the IID CIs, as expected when consecutive-day autocorrelation is respected.",
  "- A previous reviewer re-run (w2, `Paper_revision/`) used a day-level IID bootstrap (B = 2000) on a",
  "  seed-42 re-train and obtained MuSPAD RMSE 9.253 [7.353, 11.230]; the IID CIs above (paper predictions,",
  "  B = 10000) are of the same magnitude, and the moving-block CIs are wider.",
  "- The LASSO fit itself (missForest imputation + CV partition) is stochastic, but per specification the",
  "  CIs capture only the uncertainty of the test-observation resampling.",
  "")
writeLines(md, file.path(OUT_DIR, "LASSO_testset_moving_block_bootstrap_CIs.md"))

# --- console report ----------------------------------------------------------------
cat("\n================ LASSO test-set moving-block bootstrap ================\n")
cat(sprintf("n_test = %d, block = %d days, B = %d, seed = %d\n\n", n_test, BLOCK, B, SEED))
print(res, row.names = FALSE)
cat("\nFiles written to:", OUT_DIR, "\n")
