# Reproducing the paper's LASSO results

Manual for reproducing the LASSO rows of the manuscript, in the exact order the
work was done, and how it connects to the earlier scripts in this repo
(`Data_Preprocessing`, `Compare_models`).

Paper results covered:

- **Table 1** (main text) — seven-day incidence prediction performance:
  RMSE and sMAPE, training and test, MuSPAD model and time-only baseline.
- **Table S3** (supplement) — additional metrics: MAE, MASE, R², with the same
  test-set confidence intervals.
- **Table S5** (supplement) — calibration of the test predictions
  (regressing observed on predicted incidence).

No reruns were needed to produce the paper's numbers: every published LASSO
value is computed from two saved prediction files (Section 2), and all values
were re-verified against those files (Section 8). Everything this manual
references — all six scripts, the two anchor prediction files, the dataset,
the Step 5 comparison inputs, and every result artifact — is committed in
this repo (byte-identical copies of the `S:` originals), so it can be
followed end-to-end without access to the `S:` drive (Section 4.1).

## 1. The two published tables and the LASSO rows

Table 1 (main text), footnote: *"For LASSO, training values are from a single
deterministic fit and test values are accompanied by 95% moving-block bootstrap
confidence intervals."*

| Metric | Training MuSPAD | Test MuSPAD | Training baseline | Test baseline |
|---|---|---|---|---|
| RMSE | 33.09 | 9.28 (5.13–10.10) | 70.73 | 61.70 (60.38–65.09) |
| sMAPE | 0.39 | 1.07 (0.86–1.19) | 0.91 | 1.46 (1.41–1.62) |

Table S3 (supplement), footnote: MASE is relative to a one-step persistence
forecast on the training series; test-set CIs are 95% moving-block bootstrap
(same protocol as Table 1).

| Metric | Training MuSPAD | Test MuSPAD | Training baseline | Test baseline |
|---|---|---|---|---|
| MAE | 20.55 | 8.05 (4.71, 9.21) | 50.02 | 61.45 (60.00, 65.07) |
| MASE | 3.62 | 1.42 (0.83, 1.62) | 8.81 | 10.82 (10.56, 11.46) |
| R² | 0.74 | −2.35 (−12.66, −1.18) | −0.20 | −147.37 (−998.27, −111.13) |

Table S5 (supplement): calibration `y = α + βŷ + ε`, OLS on the 27 held-out
test observations, conventional t-intervals (df = 25); ideal α = 0, β = 1.

| Model | Intercept α (95% CI) | Slope β (95% CI) |
|---|---|---|
| LASSO MuSPAD | 8.04 (4.27, 11.81) | 1.00 (0.10, 1.91) |
| LASSO baseline | −1.04 (−52.70, 50.63) | 0.17 (−0.53, 0.88) |

## 2. Key idea: everything derives from two saved prediction files

All published LASSO values are computed **from saved real-versus-predicted
pairs — no script re-fits a model**:

| File (repo: `Compare_models\Graphics\Predicted_values\`) | R object | Content |
|---|---|---|
| `LASSO_7day_MuSPAD.RData` | `graph_LASSO_7day_M` | Long-format data frame: `time`, `Incidence`, `real_vs_pred` ∈ {real, predicted}, `set` ∈ {Training, Test}; 251 training + 27 test days; natural (back-transformed) incidence scale |
| `LASSO_7day_baseline.RData` | `graph_LASSO_7day_BL` | Same structure, time-only model |

- Test window: 2021-07-16 … 2021-08-23, 27 reporting days; reporting gaps:
  one 7-day gap (2021-07-21 … 27) plus five isolated single-day gaps
  (2021-07-18, 08-01, 08-08, 08-15, 08-22).
- These two files are the output of Step 1 below and are consumed by Steps 2–4
  and by the cross-model `Compare_models` scripts.
- The repo's copies are byte-identical to the originals on
  `S:\...\muspad-ml-loki-sp2.1\Compare_models\Graphics\Predicted_values\`.
  **Do not overwrite the repo or the `S:` copies** — the paper's exact numbers
  are anchored to this one saved run.

## 3. Provenance: which script produced which table

| Paper values | Script (all in this repo, `LASSO\`) | Committed artifact in `LASSO\repro_results\` |
|---|---|---|
| Table 1 — test-set 95% CIs (RMSE, sMAPE) | [`LASSO_testset_moving_block_bootstrap.R`](LASSO_testset_moving_block_bootstrap.R) | `bootstrap_ci_LASSO_testset.csv` |
| Table 1 — RMSE/sMAPE point estimates (training + test) | [`lasso_fullmetrics_pi_2026-10-02.R`](lasso_fullmetrics_pi_2026-10-02.R) | `lasso_fullmetrics_2026-10-02.csv` |
| Table S3 — MAE, MASE, R² + moving-block CIs | [`lasso_fullmetrics_pi_2026-10-02.R`](lasso_fullmetrics_pi_2026-10-02.R) | `lasso_fullmetrics_2026-10-02.csv` |
| Table S5 — calibration intercept/slope + t-CIs | [`lasso_pointcalibration_2026-10-02.R`](lasso_pointcalibration_2026-10-02.R) | `lasso_pointcalibration_2026-10-02.csv` |

The fullmetrics script internally **re-derives the exact same moving-block
resampling** as the bootstrap script (guard checks G2/G3 verify bit-identical
RMSE/sMAPE samples and CIs) and simply extends it to MAE/MAPE/R²/MASE — so the
Table 1 CIs in `lasso_fullmetrics_2026-10-02.csv` and in
`bootstrap_ci_LASSO_testset.csv` are identical numbers.

## 4. Prerequisites

1. **Repo content**: everything this manual references is committed in this
   repo — the six `LASSO` scripts, the two anchor prediction files
   (`Compare_models\Graphics\Predicted_values\`), the modeling dataset
   (`Datasets\`), the Step 5 comparison inputs
   (`LASSO\mse_LASSO_*.csv` and `LASSO\Variablelist_LASSO_varsubsetbasic_2025-09-01.RData`),
   and every result artifact (`LASSO\repro_results\`). The repo copies are
   byte-identical to the originals on `S:` (SHA-256 verified when added).
2. **R packages**:
   - Step 1 model scripts: `tidyverse`, `glmnet`, `missForest`, `Metrics`.
   - Steps 2–4: base R + `Metrics` (RMSE/sMAPE definitions); the dated scripts
     write `.xlsx` twins (needs an xlsx-capable R setup as used at runtime).
   - Step 5: `glmnet`, `missForest`, `Metrics`.
3. **Dataset**: `Datasets\Time_series_data_incidence_1W_binary_classnumber_var_subset_missing_zero_2025-02-14.RData`
   (object `df_ts_inc`), see Step 1 / Section 6. Needed only by Step 1 (refit)
   and Step 5 (sanity check); Steps 2–4 work from the anchor files alone.

### 4.1 Running the scripts without the `S:` drive

The scripts are verbatim copies of the project scripts, so they still hardcode
two `S:` roots (in both the `/` and the `\`-escaped forms). On the original
machine they run as-is; to rerun from this repo on any other machine, replace
every occurrence of the two roots:

| Root in the scripts | Replace with |
|---|---|
| `S:\PROJACTIVE\MUSPAD-LABORERGEBNISSE\LOKI_ML\Datasets` | `<repo>\Datasets` |
| `S:\PROJACTIVE\MUSPAD-LABORERGEBNISSE\LOKI_ML\muspad-ml-loki-sp2.1` | `<repo>` |

(`<repo>` = this repo's root, the folder containing `Datasets\`, `LASSO\`, and
`Compare_models\`.) Affected constants per script:

| Script | Constants to swap |
|---|---|
| `LASSO_model_levelcount_..._var_imp.R` | `setwd` calls at lines 12 (Datasets), 89, 161, 167, 187, 191 |
| `LASSO_model_only_time_log_all_cities.R` | `setwd` calls at lines 9 (Datasets), 126, 131, 152, 156 |
| `LASSO_testset_moving_block_bootstrap.R` | `LASSO_DIR` (line 39), `PV_DIR` (line 40); `OUT_DIR` (line 41) derives from `LASSO_DIR` |
| `lasso_fullmetrics_pi_2026-10-02.R` | `PV_DIR` (line 53), `LASSO_DIR` (line 54), `OUT_DIR` (line 55 — point at the repo's `LASSO\repro_results`) |
| `lasso_pointcalibration_2026-10-02.R` | `PV_DIR` (line 40), `OUT_DIR` (line 41 — same) |
| `LASSO_reproduce_paper_results.R` | `DATA_FILE` (line 33), `LASSO_DIR` (line 34), `PV_DIR` (line 35) |

Notes:

- Rerunning Step 1 from the repo **overwrites the committed anchor files**
  with a new stochastic run — back them up first (or keep Path A, which never
  reruns Step 1).
- Rerunning Steps 2–4 with swapped paths regenerates the committed
  `repro_results` files with identical content: they are deterministic given
  the anchors and the fixed seeds (42 for the bootstrap, 20261025 for the PI
  coverage; Step 4 has no seed).
- The model scripts also write PNG graphics into `LASSO\Graphics\` and
  `Compare_models\Graphics\Single_graphics\` (folders created on demand);
  those graphics are the only Step 1 outputs not committed to the repo.

## 5. Ordered steps

### Step 1 — Fit the two LASSO models (the original, unseeded runs)

Scripts (in repo):

1. **MuSPAD model** —
   [`LASSO_model_levelcount_log_scale_all_cities_varsubsetbasic_without_cities_var_imp.R`](LASSO_model_levelcount_log_scale_all_cities_varsubsetbasic_without_cities_var_imp.R)
2. **Time-only baseline** —
   [`LASSO_model_only_time_log_all_cities.R`](LASSO_model_only_time_log_all_cities.R)

What the MuSPAD script does (baseline differs as noted):

1. Loads the latest file matching `binary_classnumber_var_subset_missing_zero`
   in the `Datasets` folder (object `df_ts_inc`; the file used for the paper's
   run — and the only one committed in the repo's `Datasets\` — is the
   2025-02-14 one).
2. Drops `time_day == 168` → 279 rows; target = column 1 (weekly incidence at
   `t + 7`), log-transformed.
3. Chronological split: rows 1–251 = training, rows 252–278 = test (27 days).
   Row 279 is **unused** — the original code indexes with `1:(n/10*9)` and
   `(n/10*9+1):n`, which have non-integer endpoints for n = 279.
4. MuSPAD only: `missForest` imputation separately on training and test
   (**unseeded**), then z-scaling with the training set's center/scale.
5. 10-fold `cv.glmnet` (alpha = 1; lambda grid 10^(2…−2) for MuSPAD,
   10^(3…−3) for the baseline; fold partitioning **unseeded**); refit at
   `lambda.min`.
6. Predicts, back-transforms (`exp`), computes MSE via `Metrics::mse`.

Outputs written by the scripts (repo paths). The first three rows are
committed in this repo (byte-identical to the `S:` originals); the PNG row is
not (regenerable):

| Output | Location | Committed in repo |
|---|---|---|
| `Variablelist_LASSO_varsubsetbasic_<date>.RData` (ranked non-zero coefficients; only the latest run, 2025-09-01) | `LASSO\` | yes |
| `mse_LASSO_MuSPAD.csv` / `mse_LASSO_onlyTime.csv` (train/test MSE) | `LASSO\` | yes |
| **`LASSO_7day_MuSPAD.RData` / `LASSO_7day_baseline.RData`** ← the paper anchors | `Compare_models\Graphics\Predicted_values\` | yes |
| Real-vs-predicted PNGs (several runs, 2025-02 … 2025-09) | `LASSO\Graphics\`, `Compare_models\Graphics\Single_graphics\` | no |

Notes:

- The baseline uses a single raw feature (`time_day`), no imputation, no
  scaling. It is effectively deterministic: re-fitting with a fixed seed (1)
  reproduced the saved paper pairs exactly.
- The MuSPAD model is **stochastic** (unseeded imputation + CV partition).
  Rerunning Step 1 gives a *new* run whose metrics differ slightly from the
  paper's (Section 5, Step 5 quantifies the spread). For the exact paper
  values, use the existing anchor files — do not rerun Step 1 on top of them.

Two paths from here:

- **Path A (exact paper values):** keep the existing
  `LASSO_7day_*.RData` anchors and run Steps 2–4. This reproduces every
  published LASSO number exactly (verified, Section 8).
- **Path B (full rerun from the dataset):** run Step 1 fresh, then Steps 2–4
  on the new anchors. Values land within the stochastic range of the saved
  run (the paper's values sit inside the 10-seed refit range, Step 5).

### Step 2 — Table 1 test-set CIs: moving-block bootstrap

[`LASSO_testset_moving_block_bootstrap.R`](LASSO_testset_moving_block_bootstrap.R)

- **Reads:** both anchor files (the `set == "Test"` rows, n = 27 per model).
- **Method:** moving-block bootstrap of the held-out test observations —
  block length 7 (one week), B = 10,000, seed 42; an IID bootstrap is included
  for comparison. 95% percentile CIs for RMSE and sMAPE (0–2 scale),
  `Metrics`-consistent definitions. No model refitting.
- **Writes** to `LASSO\repro_results\` (via `LASSO_DIR`, see 4.1):
  `bootstrap_ci_LASSO_testset.csv`, `boot_samples_LASSO_testset.rda`,
  `LASSO_testset_moving_block_bootstrap_CIs.md` — all committed in the repo.
- **Feeds:** the four Table 1 confidence intervals:
  9.28 (5.13–10.10), 61.70 (60.38–65.09), 1.07 (0.86–1.19), 1.46 (1.41–1.62).

### Step 3 — Table 1 point estimates + Table S3: full metrics

[`lasso_fullmetrics_pi_2026-10-02.R`](lasso_fullmetrics_pi_2026-10-02.R)

- **Reads:** both anchor files (Training n = 251 + Test n = 27) **plus** the
  Step 2 artifacts (`boot_samples_LASSO_testset.rda`,
  `bootstrap_ci_LASSO_testset.csv`) as guard references.
- **Method:** on training and test, natural incidence scale: RMSE, sMAPE
  (0–2), R² (around the set's own mean), MAE, MAPE, and MASE (MAE divided by
  the in-sample one-step persistence MAE of the training series; 250
  consecutive pairs, with a 204 calendar-adjacent-pair alternative reported).
  Extends the Step 2 moving-block resampling (bit-identical, per guard
  checks) to MAE/MAPE/R²/MASE. Guard checks: G1 point estimates within
  2-decimal rounding of the paper; G2 recomputed RMSE/sMAPE bootstrap samples
  identical to the saved `.rda`; G3 CIs identical to
  `bootstrap_ci_LASSO_testset.csv`.
- **Also writes** `lasso_pi_coverage_2026-10-02.csv/.xlsx`: prediction
  intervals + coverage via residual bootstrap (seed 20261025, B = 2000) —
  supplementary context, not in the published tables.
- **Writes** to its local `OUT_DIR` (set at the top of the script; at runtime
  it was a local temp folder whose output was copied into
  `LASSO\repro_results\`):
  `lasso_fullmetrics_2026-10-02.csv/.xlsx`, `lasso_pi_coverage_2026-10-02.csv/.xlsx`,
  `lasso_fullmetrics_pi_README_2026-10-02.md` — all committed in
  `LASSO\repro_results\` (on a rerun, point `OUT_DIR` there; see 4.1).
- **Feeds:** all of Table S3 (MAE/MASE/R² point estimates and moving-block
  CIs) and the Table 1 RMSE/sMAPE point estimates (cross-checked to 2 decimals).

### Step 4 — Table S5: calibration

[`lasso_pointcalibration_2026-10-02.R`](lasso_pointcalibration_2026-10-02.R)

- **Reads:** both anchor files (test rows) **plus** Step 3's
  `lasso_pi_coverage_2026-10-02.csv` (guard G2 verifies the per-day
  actual/predicted pairs are identical) — so **Step 3 must have run first in
  the same output directory**.
- **Method:** OLS `y = α + βŷ + ε` on the 27 held-out test days, natural
  scale, fully deterministic (no seed); t-based 95% CIs (df = 25); joint F
  test of H₀: (α, β) = (0, 1).
- **Writes** (same local `OUT_DIR`, mirrored into `LASSO\repro_results\`):
  `lasso_pointcalibration_2026-10-02.csv/.xlsx/.png` — committed in
  `LASSO\repro_results\`.
- **Feeds:** Table S5 — MuSPAD 8.04 (4.27, 11.81) / 1.00 (0.10, 1.91);
  baseline −1.04 (−52.70, 50.63) / 0.17 (−0.53, 0.88).

### Step 5 (optional) — Refit sanity check

[`LASSO_reproduce_paper_results.R`](LASSO_reproduce_paper_results.R)

- **Does not** depend on the saved predictions for its main result: it
  **re-fits both protocols from the dataset** (the committed
  `Datasets\..._2025-02-14.RData`, via the script's `DATA_FILE` constant) on
  seeds 1–10 (plus a canonical seed 42) and compares the five metrics of the
  original scripts (MSE, RMSE, MAPE, SMAPE, RMSLE), training and test, against
  (a) the paper's tables and (b) the committed `mse_LASSO_*.csv` files; it also
  compares the seed-42 test predictions against the saved paper pairs and the
  selected variables against the committed latest `Variablelist_*` file
  (2025-09-01).
- **Writes** to `LASSO\repro_results\` (via `LASSO_DIR`, see 4.1):
  `seed_sweep_LASSO_all_seeds.csv`, `real_vs_pred_MuSPAD_seed42.csv`,
  `real_vs_pred_onlyTime_seed42.csv`, `repro_summary_vs_paper.csv`,
  `repro_summary_vs_team_csv.csv`.
- **Result (run 2026-10-02):** every paper test value lies inside the
  10-seed refit range; the one apparent exception (baseline RMSLE 1.89 vs.
  range maximum 1.8887) resolves on 2-decimal rounding (1.8887 → 1.89).
- This step is **not needed** to produce the table values; it documents that
  a from-scratch refit lands within stochastic variation of the saved run.

## 6. Connection to the earlier scripts

```text
Data_Preprocessing/01_Data_Aggregation.R  ─┐
Data_Preprocessing/02_Prepare_for_Analysis.R ─┘
   │  builds the weekly MuSPAD + RKI-incidence dataset df_ts_inc
   │  (incidence at t+7 vs. features at t; time_day = days since 2020-01-01)
   ▼
Datasets\*binary_classnumber_var_subset_missing_zero*.RData
   │  (repo: Datasets\; zero-filled variant of the basic var-subset dataset;
   │   the paper's run used the 2025-02-14 file. Same "latest matching file"
   │   convention as all MLP scripts in this repo.)
   ▼
Step 1: the two LASSO model scripts (unseeded)
   ├──► LASSO\Variablelist_*, mse_LASSO_*.csv, PNGs
   └──► Compare_models\Graphics\Predicted_values\LASSO_7day_{MuSPAD,baseline}.RData
          │                    (the paper anchors — shared artifacts)
          ├──► Step 2  bootstrap CIs           ──► Table 1 CIs
          ├──► Step 3  fullmetrics + PI        ──► Table 1 points + Table S3
          ├──► Step 4  point calibration       ──► Table S5
          ├──► Step 5  refit sanity check (optional, dataset only)
          └──► Compare_models/Metrics_all_models*.R  (cross-model tables)
               Compare_models/Graphic_grid.R         (comparison figure)
```

- **Upstream (dataset).** `Data_Preprocessing/01_Data_Aggregation.R`
  aggregates the cleaned participant-level MuSPAD data by day;
  `Data_Preprocessing/02_Prepare_for_Analysis.R` filters features and joins
  county-level RKI incidence, creating the time-agnostic modeling dataset
  (`df_ts_inc`, aligned at t / t+7) that the LASSO scripts load. The LASSO
  scripts use column 1 (incidence at `t + 7`, log-transformed) and column 2
  (`time_day`). The exact `..._missing_zero_2025-02-14.RData` file is the
  zero-filled variant of that basic dataset; it is loaded via the
  latest-matching-file convention. The paper's file is committed in the
  repo's `Datasets\` folder (and on `S:`), and it is the only file there
  matching the pattern.
- **Downstream (cross-model).** `Compare_models/Metrics_all_models.R` (and its
  14-day / three-quarters variants) loads the same two `LASSO_7day_*.RData`
  files together with every other model's saved predictions and produces the
  wide cross-model metric tables (MAPE, SMAPE, RMSLE, RMSE) plus LaTeX table
  code; `Compare_models/Graphic_grid.R` builds the faceted
  real-versus-predicted figure from the same objects. The two RData files are
  therefore shared artifacts: Steps 2–4 use them for the LASSO-specific
  Table 1 / S3 / S5 values, while the `Compare_models` scripts use them for
  the cross-model comparison.
- **Metric definitions.** The cross-model `Metrics_all_models.R` tables
  compute their own metric set without bootstrap CIs; the LASSO rows
  *published* in the paper (Table 1, S3, S5) come from Steps 2–4.

## 7. Output artifact inventory (committed in `LASSO\repro_results\`)

| Artifact | Written by |
|---|---|
| `bootstrap_ci_LASSO_testset.csv` | Step 2 (bootstrap script) |
| `boot_samples_LASSO_testset.rda` | Step 2 (bootstrap script) |
| `LASSO_testset_moving_block_bootstrap_CIs.md` | Step 2 (bootstrap script) |
| `lasso_fullmetrics_2026-10-02.csv/.xlsx` | Step 3 (fullmetrics script) |
| `lasso_pi_coverage_2026-10-02.csv/.xlsx` | Step 3 (fullmetrics script) |
| `lasso_fullmetrics_pi_README_2026-10-02.md` | Step 3 (fullmetrics script) |
| `lasso_pointcalibration_2026-10-02.csv/.xlsx/.png` | Step 4 (calibration script) |
| `seed_sweep_LASSO_all_seeds.csv` | Step 5 (reproduce script) |
| `real_vs_pred_MuSPAD_seed42.csv`, `real_vs_pred_onlyTime_seed42.csv` | Step 5 (reproduce script) |
| `repro_summary_vs_paper.csv`, `repro_summary_vs_team_csv.csv` | Step 5 (reproduce script) |

The committed copies are the results of the 2026-10-01/02 runs on the `S:`
machine: Steps 2 and 5 write directly into `LASSO\repro_results\`, while
Steps 3 and 4 write to a local `OUT_DIR` defined at the top of each script,
whose output was then copied into the same `repro_results` folder. Re-running
any step with the paths swapped per 4.1 regenerates identical files
(deterministic given the anchors and the fixed seeds).

## 8. Verification against the paper

All values below were read from the Step 2–4 artifacts and match the published
tables after 2-decimal rounding (verified 2026-10-02).

| Paper cell | Artifact value |
|---|---|
| T1 RMSE test MuSPAD 9.28 (5.13–10.10) | 9.2784 [5.1328, 10.0984] |
| T1 RMSE test baseline 61.70 (60.38–65.09) | 61.7042 [60.3750, 65.0905] |
| T1 sMAPE test MuSPAD 1.07 (0.86–1.19) | 1.0680 [0.8642, 1.1862] |
| T1 sMAPE test baseline 1.46 (1.41–1.62) | 1.4620 [1.4105, 1.6233] |
| T1 RMSE train 33.09 / 70.73 | 33.0905 / 70.7291 |
| T1 sMAPE train 0.39 / 0.91 | 0.3919 / 0.9115 |
| S3 MAE test 8.05 (4.71, 9.21) / 61.45 (60.00, 65.07) | 8.0531 [4.7111, 9.2095] / 61.4500 [59.9958, 65.0661] |
| S3 MASE test 1.42 (0.83, 1.62) / 10.82 (10.56, 11.46) | 1.4181 [0.8296, 1.6217] / 10.8210 [10.5649, 11.4577] |
| S3 R² test −2.35 (−12.66, −1.18) / −147.37 (−998.27, −111.13) | −2.3546 [−12.6583, −1.1756] / −147.3650 [−998.2715, −111.1299] |
| S3 train MAE/MASE/R² 20.55 / 3.62 / 0.74 and 50.02 / 8.81 / −0.20 | 20.5507 / 3.6188 / 0.7371 and 50.0204 / 8.8083 / −0.2012 |
| S5 MuSPAD 8.04 (4.27, 11.81) / 1.00 (0.10, 1.91) | 8.0437 [4.2724, 11.8149] / 1.0026 [0.0980, 1.9072] |
| S5 baseline −1.04 (−52.70, 50.63) / 0.17 (−0.53, 0.88) | −1.0379 [−52.7025, 50.6266] / 0.1736 [−0.5325, 0.8798] |

## 9. Caveats

- **Hardcoded `S:` paths** in every script (they are verbatim copies of the
  project scripts). They run as-is on the original machine; to run anywhere
  else, apply the root swaps in Section 4.1.
- **Do not overwrite the anchor files** (`LASSO_7day_*.RData`) when rerunning
  Step 1 — neither the repo's copies nor the `S:` originals; the paper's
  values are tied to that saved run.
- The repo's data and result files (anchors, dataset, Variablelist,
  `repro_results`) are byte-identical copies of the `S:` originals (SHA-256
  verified when added); treat both as canonical, with the `S:` drive remaining
  the live working copy of the project.
- The MuSPAD model is stochastic by construction (no seed in the original
  scripts); only the time-only baseline refits deterministically.
- Test-set R² is strongly negative because the 27-day test window is a quiet
  post-outbreak period (actuals 4.9–23.3, small SST) — a property of the data,
  not a computation issue.
- sMAPE is on the 0–2 scale: `mean(2|a − f| / (|a| + |f|))`.
- Row 279 of the dataset is never used (see Step 1, point 3).
