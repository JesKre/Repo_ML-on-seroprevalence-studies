# LASSO

LASSO analysis for the manuscript: the main MuSPAD LASSO model, the time-only
LASSO baseline, the bootstrap confidence intervals (CIs) for the test-set
error metrics (RMSE, SMAPE), and the scripts that derive the paper's
Table 1 / S3 / S5 values from the saved predictions. All inputs and result
artifacts behind the paper's rows are committed in this repo (this folder,
`Compare_models/Graphics/Predicted_values/`, `Datasets/`) — see the
reproduction manual below.

## Reproduction manual

For the full ordered procedure that produced the paper's LASSO rows (Table 1,
Tables S3 and S5), the script-to-table mapping, the artifact inventory, and
the connection to the earlier `Data_Preprocessing` and `Compare_models`
scripts, see [`REPRODUCTION_MANUAL.md`](REPRODUCTION_MANUAL.md).

## Scripts

| Script | Purpose |
|---|---|
| [`LASSO_model_levelcount_log_scale_all_cities_varsubsetbasic_without_cities_var_imp.R`](LASSO_model_levelcount_log_scale_all_cities_varsubsetbasic_without_cities_var_imp.R) | Fits the main MuSPAD LASSO model: chronological 90/10 train-test split, separate `missForest` imputation, training-derived z-scaling, log-incidence target, 10-fold `cv.glmnet` selection of `lambda.min`, back-transformed predictions, error metrics, ranked non-zero coefficients, and saved real-versus-predicted objects. |
| [`LASSO_model_only_time_log_all_cities.R`](LASSO_model_only_time_log_all_cities.R) | Fits the time-only LASSO baseline with the same chronological split, log-incidence target, 10-fold lambda selection, back-transformed predictions, metrics, and plotting outputs. |
| [`LASSO_testset_moving_block_bootstrap.R`](LASSO_testset_moving_block_bootstrap.R) | Computes 95% CIs for the test-set RMSE and SMAPE of both LASSO models by moving-block bootstrap (block length 7, B = 10000, seed 42) on the saved paired test predictions, with an IID bootstrap included for comparison. No model re-fitting. |
| [`lasso_fullmetrics_pi_2026-10-02.R`](lasso_fullmetrics_pi_2026-10-02.R) | Computes the Table 1 point estimates (RMSE, sMAPE) and the full Table S3 metric set (MAE, MASE, R², MAPE) from the saved anchor predictions, re-derives the bootstrap script's moving-block resampling bit-identically as a guard, and adds prediction-interval coverage by residual bootstrap (seed 20261025, B = 2000). |
| [`lasso_pointcalibration_2026-10-02.R`](lasso_pointcalibration_2026-10-02.R) | Computes Table S5: OLS calibration of the 27 held-out test predictions (intercept/slope with t-based 95% CIs and a joint test of α = 0, β = 1). Fully deterministic; reads the fullmetrics script's PI-coverage CSV as a guard, so it must run after it. |
| [`LASSO_reproduce_paper_results.R`](LASSO_reproduce_paper_results.R) | Optional refit sanity check: re-fits both protocols from the dataset on seeds 1–10 (plus a canonical seed 42) and compares the five original metrics against the paper's tables, the saved `mse_LASSO_*.csv` files, the anchor predictions, and the latest `Variablelist_*` file. |

## Test-set confidence intervals

### Which script computes them

`LASSO_testset_moving_block_bootstrap.R` is the script responsible for the
test-set CIs. It reads the exact saved predictions behind the paper's
published point estimates — no re-fitting — and quantifies the uncertainty of
the test error by resampling the held-out test observations.

### Dependency chain

```text
LASSO_model_levelcount_..._var_imp.R   ──> Compare_models/Graphics/Predicted_values/LASSO_7day_MuSPAD.RData    (object graph_LASSO_7day_M)
LASSO_model_only_time_log_all_cities.R ──> Compare_models/Graphics/Predicted_values/LASSO_7day_baseline.RData  (object graph_LASSO_7day_BL)
                     │
                     ▼
LASSO_testset_moving_block_bootstrap.R ──> LASSO/repro_results/bootstrap_ci_LASSO_testset.csv
                                           LASSO/repro_results/LASSO_testset_moving_block_bootstrap_CIs.md
                                           LASSO/repro_results/boot_samples_LASSO_testset.rda
```

The two model scripts must have been run (or the two `.RData` prediction
objects must otherwise exist) before the bootstrap script. If the model
scripts are re-run, `missForest` imputation and the `cv.glmnet` folds are
stochastic, so the point estimates will differ slightly from the paper; the
CIs then refer to the re-fitted predictions.

### Method

- **Test set:** the held-out 10% block = 27 observations, 2021-07-16 ..
  2021-08-23 (near-consecutive days; reporting gaps: one 7-day gap,
  2021-07-21..27, plus five isolated single-day gaps).
- **Resampling:** moving-block bootstrap with block length `b = 7`, matching
  the 7-day forecasting horizon. Consecutive days are autocorrelated, so an
  IID resample understates the uncertainty of the test error.
- **Per replicate:** `K = ceiling(27/7) = 4` blocks; block start positions
  sampled with replacement from the 21 possible positions; the 28 resampled
  observations are truncated back to 27.
- **B = 10000** replicates; per replicate, RMSE and SMAPE (Metrics-package
  definitions) are recomputed on the resampled (real, predicted) pairs.
- **95% CI** = 2.5th / 97.5th percentile of the bootstrap distribution.
- **Seed = 42.** An IID (single-observation) bootstrap with the same B and
  seed is reported alongside for comparison.

The bootstrap itself is fully deterministic given the seed; a re-run on the
same saved predictions reproduces the CIs exactly.

### Outputs

Written to `LASSO/repro_results/`:

| File | Content |
|---|---|
| `bootstrap_ci_LASSO_testset.csv` | One row per model × metric × method (moving-block and IID): point estimate, CI bounds, B, block length, n. |
| `LASSO_testset_moving_block_bootstrap_CIs.md` | Markdown summary with the results table and consistency checks. |
| `boot_samples_LASSO_testset.rda` | Raw bootstrap samples (B × 27 RMSE and SMAPE values per model and method) for further analysis. |

### Reference values (deployed run, generated 2026-10-01)

| model | metric | point estimate | moving-block 95% CI | IID 95% CI (comparison) |
|---|---|---:|---|---|
| MuSPAD | RMSE | 9.278 | [5.133, 10.098] | [7.311, 11.142] |
| MuSPAD | SMAPE | 1.068 | [0.864, 1.186] | [0.931, 1.188] |
| onlyTime | RMSE | 61.704 | [60.375, 65.090] | [59.582, 63.511] |
| onlyTime | SMAPE | 1.462 | [1.411, 1.623] | [1.384, 1.538] |

Consistency checks: the point estimates reproduce the paper's Table 1
(MuSPAD RMSE 9.28 / sMAPE 1.07; onlyTime RMSE 61.70 / sMAPE 1.46), and the
moving-block CIs are wider than the IID CIs, as expected when
consecutive-day autocorrelation is respected.

### Scope of the CIs

Per specification, the CIs capture only the uncertainty of the
test-observation resampling. They do **not** include the stochasticity of
the LASSO fit itself (`missForest` imputation, 10-fold CV, and `glmnet`
standardization are not seeded).

## Notes

- All scripts are verbatim copies of the original project scripts, which
  retain absolute Windows paths
  (`S:\PROJACTIVE\MUSPAD-LABORERGEBNISSE\LOKI_ML\...`). They are analysis
  scripts rather than a portable pipeline; see the reproduction manual
  (Section 4.1) for the exact path swaps to run them from this repo without
  the `S:` drive, and the root README for the general convention.
- Committed inputs and results (byte-identical to the `S:` originals,
  SHA-256 verified when added): the anchor prediction files in
  `Compare_models/Graphics/Predicted_values/`, the modeling dataset in
  `Datasets/`, the Step 5 comparison inputs (`mse_LASSO_*.csv`,
  `Variablelist_LASSO_varsubsetbasic_2025-09-01.RData`), and all result
  artifacts in `repro_results/` — see the reproduction manual.
- Packages: model scripts need `tidyverse`, `glmnet`, `missForest`,
  `Metrics`; the bootstrap script needs only `Metrics`.
- The scripts are single end-to-end scripts, not interactive sessions; run
  each to completion.
