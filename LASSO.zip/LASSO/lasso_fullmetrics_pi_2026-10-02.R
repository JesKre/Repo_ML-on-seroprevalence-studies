# ============================================================================
# lasso_fullmetrics_pi_2026-10-02.R
# ----------------------------------------------------------------------------
# Full metric set + test-set calibration for the two LASSO models behind the
# paper's Tables 1-5. Computed ENTIRELY from the saved paper predictions
# (no re-fitting, no re-imputation):
#   Compare_models/Graphics/Predicted_values/LASSO_7day_MuSPAD.RData
#   Compare_models/Graphics/Predicted_values/LASSO_7day_baseline.RData
#
# Data: 251 training + 27 held-out test observations (2021-07-16..2021-08-23,
#       irregular reporting dates; one 8-day gap inside the test block).
#
# Metrics (original incidence scale; Training n=251 and Test n=27):
#   RMSE, sMAPE (0-2 scale, 2|e|/(|a|+|f|)), R^2 (around the set's own mean),
#   MAE, MAPE (finite here: all predictions > 0, all actuals > 0),
#   MASE (denominator = in-sample persistence MAE of the training series,
#         PRIMARY: 250 consecutive pairs in series order [textbook 1-step
#         naive]; ALTERNATIVE: 204 calendar-adjacent pairs, both reported).
#
# Bootstrap CIs (test set only):
#   EXACT replication of the locked protocol
#   LASSO/LASSO_testset_moving_block_bootstrap.R (seed 42, B = 10000,
#   moving-block b = 7 + IID, call order per model: MB then IID), extended
#   to the new metrics. Guard checks:
#     G2: recomputed RMSE/sMAPE replicates bit-identical (< 1e-12) to the
#         stored boot_samples_LASSO_testset.rda;
#     G3: recomputed RMSE/sMAPE moving-block CIs identical to
#         bootstrap_ci_LASSO_testset.csv;
#     G1: point estimates match the paper's 2-decimal tables (<= 0.005).
#
# Calibration (test set) -- LASSO analogue of the VAR innovation-bootstrap PI:
#   - pool = 251 in-sample residuals on the log scale (models were fit on
#     log incidence): e_t = log(real_t) - log(pred_t), t in Training.
#   - the LASSO models are NON-recursive (each test day predicted from its
#     own feature row), so each test day's error is a single residual draw;
#     no horizon accumulation, PI width constant across the 27 days.
#   - B = 2000 replicates, seed 20261025 set ONCE before the model loop
#     (VAR PI convention): y*_b,t = f_t + e*_{b,t}, e* ~ iid pool;
#     PI_t = 2.5/97.5 percentiles (type 7); reported back-transformed.
#   - coverage = fraction of test days with actual inside PI; 95%
#     Clopper-Pearson CI via binom.test.
#   - sensitivity: normal-theory PI f_t +/- qnorm(.025/.975) * sd(pool).
#
# Outputs (local; mirrored to S:...\LASSO\repro_results\):
#   lasso_fullmetrics_2026-10-02.csv   (+ .xlsx twin)
#   lasso_pi_coverage_2026-10-02.csv   (+ .xlsx twin)
#   lasso_fullmetrics_pi_README_2026-10-02.md
# ============================================================================

options(warn = 1)
suppressMessages(library(Metrics))

PV_DIR    <- "S:/PROJACTIVE/MUSPAD-LABORERGEBNISSE/LOKI_ML/muspad-ml-loki-sp2.1/Compare_models/Graphics/Predicted_values"
LASSO_DIR <- "S:/PROJACTIVE/MUSPAD-LABORERGEBNISSE/LOKI_ML/muspad-ml-loki-sp2.1/LASSO"
OUT_DIR   <- "C:/Users/abz26/AppData/Local/Temp/opencode/lasso"
dir.create(OUT_DIR, showWarnings = FALSE, recursive = TRUE)

B_CI  <- 10000; BLOCK <- 7L; SEED_CI <- 42
B_PI  <- 2000;  SEED_PI <- 20261025
DATE  <- "2026-10-02"
MODELS <- c("MuSPAD", "onlyTime")

models <- list(
  list(name = "MuSPAD",   file = "LASSO_7day_MuSPAD.RData",   obj = "graph_LASSO_7day_M"),
  list(name = "onlyTime", file = "LASSO_7day_baseline.RData", obj = "graph_LASSO_7day_BL"))

# ---------------------------------------------------------------------------
# Load training + test pairs from the saved RData
# ---------------------------------------------------------------------------
load_pairs <- function(m) {
  env <- new.env()
  load(file.path(PV_DIR, m$file), envir = env)
  d <- env[[m$obj]]
  out <- list()
  for (s in c("Training", "Test")) {
    x <- d[d[["set"]] == s, ]
    r <- x[x[["real_vs_pred"]] == "real", c("time", "Incidence")]
    p <- x[x[["real_vs_pred"]] == "predicted", c("time", "Incidence")]
    names(r)[2] <- "real"; names(p)[2] <- "predicted"
    pm <- merge(r, p, by = "time")
    pm <- pm[order(pm$time), , drop = FALSE]
    pm$real      <- as.numeric(pm$real)
    pm$predicted <- as.numeric(pm$predicted)
    out[[s]] <- pm
  }
  out
}

data <- lapply(models, load_pairs)
names(data) <- vapply(models, `[[`, character(1), "name")

# G4: structure guards -------------------------------------------------------
for (nm in MODELS) {
  tr <- data[[nm]]$Training; te <- data[[nm]]$Test
  stopifnot(nrow(tr) == 251, nrow(te) == 27)
  stopifnot(!anyNA(c(tr$real, tr$predicted, te$real, te$predicted)))
  stopifnot(all(tr$real > 0), all(tr$predicted > 0), all(te$real > 0), all(te$predicted > 0))
  stopifnot(length(unique(tr$time)) == 251, length(unique(te$time)) == 27)
}
stopifnot(identical(data[["MuSPAD"]]$Training$time, data[["onlyTime"]]$Training$time))
stopifnot(identical(data[["MuSPAD"]]$Test$time,     data[["onlyTime"]]$Test$time))
cat("G4 PASS: 251 train + 27 test pairs per model; no NA/zero; identical dates across models\n")
flush(stdout())

# ---------------------------------------------------------------------------
# MASE denominators (identical for both models: same training series)
# ---------------------------------------------------------------------------
tr_real <- data[["MuSPAD"]]$Training$real
tr_date <- as.Date(data[["MuSPAD"]]$Training$time)
d_gap   <- as.numeric(diff(tr_date))
cal_idx <- which(d_gap == 1)                       # pair (t, t-1) with calendar-adjacent dates
denom_consec  <- mean(abs(diff(tr_real)))          # 250 consecutive pairs (PRIMARY)
denom_caldays <- mean(abs(tr_real[cal_idx + 1] - tr_real[cal_idx]))  # 204 calendar-adjacent pairs
stopifnot(length(denom_consec) == 1, length(denom_caldays) == 1,
          denom_consec > 0, denom_caldays > 0)
cat(sprintf("MASE denominators: consecutive pairs (n=%d) = %.6f | calendar-adjacent (n=%d) = %.6f\n",
            length(diff(tr_real)), denom_consec, length(cal_idx), denom_caldays))
flush(stdout())

# ---------------------------------------------------------------------------
# Point metrics
# ---------------------------------------------------------------------------
metrics6 <- function(real, pred, mase_denom) {
  e     <- real - pred
  rmse  <- sqrt(mean(e^2))
  smape <- mean(2 * abs(e) / (abs(real) + abs(pred)))
  r2    <- 1 - sum(e^2) / sum((real - mean(real))^2)
  mae   <- mean(abs(e))
  mape  <- mean(abs(e) / abs(real))
  mase  <- mae / mase_denom
  c(RMSE = rmse, sMAPE = smape, R2 = r2, MAE = mae, MAPE = mape, MASE = mase)
}

# Paper values (repro_results/repro_summary_vs_paper.csv, 2 decimals)
paper <- list(
  MuSPAD = list(RMSE  = c(training = 33.09, test = 9.28),
                sMAPE = c(training =  0.39, test = 1.07),
                MAPE  = c(training =  0.45, test = 0.68)),
  onlyTime = list(RMSE  = c(training = 70.73, test = 61.70),
                  sMAPE = c(training =  0.91, test = 1.46),
                  MAPE  = c(training =  2.42, test = 6.56)))

pt <- list()
for (nm in MODELS) {
  pt[[nm]]$Training <- metrics6(data[[nm]]$Training$real, data[[nm]]$Training$predicted, denom_consec)
  pt[[nm]]$Test     <- metrics6(data[[nm]]$Test$real,     data[[nm]]$Test$predicted,     denom_consec)
}

# G1: paper cross-check (2-decimal tables) -----------------------------------
for (nm in MODELS) {
  for (s in c("training", "test")) {
    for (met in c("RMSE", "sMAPE", "MAPE")) {
      pv <- paper[[nm]][[met]][s]
      stopifnot(abs(pt[[nm]][[s]][met] - pv) <= 0.005 + 1e-9)
      cat(sprintf("G1  %s %-8s %-6s RData = %.4f  paper = %.2f  (|diff| = %.4f)\n",
                  nm, met, s, pt[[nm]][[s]][met], pv, abs(pt[[nm]][[s]][met] - pv)))
    }
  }
}
cat("G1 PASS: all point estimates reproduce the paper's Tables 1-5 (2-decimal rounding)\n")
flush(stdout())

# ---------------------------------------------------------------------------
# Bootstrap CIs on the test set -- exact replication of the locked protocol,
# extended to all six metrics
# ---------------------------------------------------------------------------
moving_block_indices <- function(n, b, B, seed) {
  K         <- ceiling(n / b)
  max_start <- n - b + 1
  set.seed(seed)
  starts <- matrix(sample.int(max_start, size = B * K, replace = TRUE), nrow = B)
  offs <- matrix(0:(b - 1), ncol = b, nrow = B, byrow = TRUE)
  idx  <- matrix(0L, nrow = B, ncol = K * b)
  for (k in seq_len(K))
    idx[, (k - 1) * b + seq_len(b)] <- starts[, k] + offs
  idx[, seq_len(n), drop = FALSE]
}
iid_indices <- function(n, B, seed) {
  set.seed(seed)
  matrix(sample.int(n, size = B * n, replace = TRUE), nrow = B)
}
boot_all <- function(idx, real, pred, denom) {
  Rm <- matrix(real[idx], nrow = NROW(idx))
  Pm <- matrix(pred[idx], nrow = NROW(idx))
  E  <- Rm - Pm
  list(
    RMSE  = sqrt(rowMeans(E^2)),
    sMAPE = rowMeans(2 * abs(E) / (abs(Rm) + abs(Pm))),
    R2    = 1 - rowSums(E^2) / rowSums((Rm - rowMeans(Rm))^2),
    MAE   = rowMeans(abs(E)),
    MAPE  = rowMeans(abs(E) / abs(Rm)),
    MASE  = rowMeans(abs(E)) / denom)
}
ci95 <- function(x) as.numeric(quantile(x, c(0.025, 0.975)))

boot_env <- new.env()
load(file.path(LASSO_DIR, "repro_results", "boot_samples_LASSO_testset.rda"), envir = boot_env)
raw_saved <- boot_env[["raw"]]
locked_ci <- read.csv(file.path(LASSO_DIR, "repro_results", "bootstrap_ci_LASSO_testset.csv"),
                      check.names = FALSE)

bootres <- list()
for (nm in MODELS) {
  real <- data[[nm]]$Test$real
  pred <- data[[nm]]$Test$predicted
  n    <- length(real)
  stopifnot(n == 27)

  mb  <- boot_all(moving_block_indices(n, BLOCK, B_CI, SEED_CI), real, pred, denom_consec)
  iid <- boot_all(iid_indices(n, B_CI, SEED_CI), real, pred, denom_consec)

  # G2: bit-identical replication of the stored RMSE/sMAPE replicates
  stopifnot(max(abs(mb$RMSE  - raw_saved[[nm]]$rmse_mb))  < 1e-12)
  stopifnot(max(abs(mb$sMAPE - raw_saved[[nm]]$smape_mb)) < 1e-12)
  stopifnot(max(abs(iid$RMSE  - raw_saved[[nm]]$rmse_iid))  < 1e-12)
  stopifnot(max(abs(iid$sMAPE - raw_saved[[nm]]$smape_iid)) < 1e-12)
  cat(sprintf("G2 PASS %s: MB/IID RMSE+sMAPE replicates bit-identical to stored rda (< 1e-12)\n", nm))

  # G3: moving-block CIs for RMSE/sMAPE identical to the locked CSV
  for (met in c("RMSE", "SMAPE")) {
    row <- locked_ci[locked_ci$model == nm & locked_ci$metric == met &
                     locked_ci$method == "moving_block", , drop = FALSE]
    stopifnot(nrow(row) == 1)
    if (met == "RMSE") { stopifnot(abs(row$ci95_lo - ci95(mb$RMSE)[1]) < 1e-12,
                                   abs(row$ci95_hi - ci95(mb$RMSE)[2]) < 1e-12) }
    else               { stopifnot(abs(row$ci95_lo - ci95(mb$sMAPE)[1]) < 1e-12,
                                   abs(row$ci95_hi - ci95(mb$sMAPE)[2]) < 1e-12) }
  }
  cat(sprintf("G3 PASS %s: MB CIs for RMSE/sMAPE identical to bootstrap_ci_LASSO_testset.csv\n", nm))

  bootres[[nm]] <- list(mb = mb, iid = iid)
  flush(stdout())
}
cat("G2/G3 PASS: bootstrap replication verified; new-metric CIs come from identical resamples\n")
flush(stdout())

# ---------------------------------------------------------------------------
# Calibration: residual (innovation) bootstrap PIs + coverage, test set
# ---------------------------------------------------------------------------
set.seed(SEED_PI)   # ONCE before the model loop (VAR PI convention)
pi_day  <- list()
pi_sum  <- list()
for (nm in MODELS) {
  tr <- data[[nm]]$Training; te <- data[[nm]]$Test
  pool <- log(tr$real) - log(tr$predicted)          # 251 in-sample log-scale residuals
  stopifnot(length(pool) == 251, all(is.finite(pool)))
  f <- log(te$predicted); a <- log(te$real)

  E  <- matrix(sample(pool, size = B_PI * 27, replace = TRUE), nrow = B_PI, ncol = 27)
  lo <- vapply(seq_len(27), function(t) quantile(E[, t], 0.025, type = 7) + f[t], numeric(1))
  hi <- vapply(seq_len(27), function(t) quantile(E[, t], 0.975, type = 7) + f[t], numeric(1))
  covered <- (a >= lo) & (a <= hi)

  sd_p  <- sd(pool)
  lo_n  <- f + qnorm(0.025) * sd_p
  hi_n  <- f + qnorm(0.975) * sd_p
  covered_n <- (a >= lo_n) & (a <= hi_n)

  bt  <- binom.test(sum(covered), 27)
  btn <- binom.test(sum(covered_n), 27)

  stopifnot(all(lo < hi), sum(covered) <= 27)
  pi_day[[nm]] <- data.frame(
    model = nm, level = "day", date = te$time,
    actual = te$real, predicted = te$predicted,
    pi_lo = exp(lo), pi_hi = exp(hi), covered = as.integer(covered),
    pi_lo_n = exp(lo_n), pi_hi_n = exp(hi_n), covered_n = as.integer(covered_n),
    pool_n = NA_integer_, pool_mean_log = NA_real_, pool_sd_log = NA_real_,
    B = NA_integer_, seed = NA_integer_,
    coverage_n = NA_integer_, coverage_frac = NA_real_, cp95_lo = NA_real_, cp95_hi = NA_real_,
    coverage_n_n = NA_integer_, coverage_frac_n = NA_real_,
    cp95_lo_n = NA_real_, cp95_hi_n = NA_real_,
    note = "")
  pi_sum[[nm]] <- data.frame(
    model = nm, level = "summary", date = "",
    actual = NA_real_, predicted = NA_real_,
    pi_lo = NA_real_, pi_hi = NA_real_, covered = NA_integer_,
    pi_lo_n = NA_real_, pi_hi_n = NA_real_, covered_n = NA_integer_,
    pool_n = 251L, pool_mean_log = mean(pool), pool_sd_log = sd_p,
    B = B_PI, seed = SEED_PI,
    coverage_n = sum(covered), coverage_frac = mean(covered),
    cp95_lo = bt$conf.int[1], cp95_hi = bt$conf.int[2],
    coverage_n_n = sum(covered_n), coverage_frac_n = mean(covered_n),
    cp95_lo_n = btn$conf.int[1], cp95_hi_n = btn$conf.int[2],
    note = "residual (innovation) bootstrap PI on log scale, non-recursive model, constant width across days")
  cat(sprintf("PI  %s: coverage %d/27 = %.3f [CP %.3f, %.3f] | normal-theory %d/27 = %.3f [CP %.3f, %.3f] | pool mean = %.4f sd = %.4f\n",
              nm, sum(covered), mean(covered), bt$conf.int[1], bt$conf.int[2],
              sum(covered_n), mean(covered_n), btn$conf.int[1], btn$conf.int[2],
              mean(pool), sd_p))
  flush(stdout())
}

# ---------------------------------------------------------------------------
# Assemble file 1: full metrics table (long format)
# ---------------------------------------------------------------------------
csv_field15 <- function(v) {
  s <- if (is.numeric(v)) sprintf("%.15g", v) else as.character(v)
  if (grepl('[";\n]', s)) s <- paste0('"', gsub('"', '""', s), '"')
  s
}
write_csv15 <- function(df, path) {
  n <- nrow(df)
  body <- vapply(seq_len(n), function(i) {
    row <- df[i, , drop = FALSE]
    paste(vapply(row, csv_field15, character(1)), collapse = ";")
  }, character(1))
  writeLines(c(paste(names(df), collapse = ";"), body), path)
}

mk_rows <- function(nm, s, pe, mb = NULL, iid = NULL) {
  mets <- c("RMSE", "sMAPE", "R2", "MAE", "MAPE", "MASE")
  do.call(rbind, lapply(mets, function(met) {
    pv  <- if (met %in% c("RMSE", "sMAPE", "MAPE")) paper[[nm]][[met]][[s]] else NA_real_
    note <- switch(met,
      RMSE  = "paper cross-check within 2-decimal rounding",
      sMAPE = "0-2 scale: mean(2|a-f|/(|a|+|f|))",
      R2    = "around the set's own mean; test window is a quiet post-outbreak period (actuals 4.9-23.3), SST small",
      MAE   = "",
      MAPE  = "finite: all predictions > 0 (exp of log-scale fit) and all actuals > 0; baseline inflated by small test actuals",
      MASE  = "MASE = MAE / in-sample 1-step persistence MAE (250 consecutive training pairs); alternative calendar-adjacent denom: see MASE_denom_* rows",
      "")
    data.frame(model = nm, set = s, metric = met, value = pe[met],
               ci_mb_lo = if (is.null(mb)) NA_real_ else ci95(mb[[met]])[1],
               ci_mb_hi = if (is.null(mb)) NA_real_ else ci95(mb[[met]])[2],
               ci_iid_lo = if (is.null(iid)) NA_real_ else ci95(iid[[met]])[1],
               ci_iid_hi = if (is.null(iid)) NA_real_ else ci95(iid[[met]])[2],
               paper_value = pv,
               abs_diff_vs_paper = if (is.na(pv)) NA_real_ else abs(pe[met] - pv),
               note = note,
               stringsAsFactors = FALSE)
  }))
}

fm_rows <- list()
for (nm in MODELS) {
  fm_rows[[length(fm_rows) + 1L]] <- mk_rows(nm, "training", pt[[nm]]$Training)
  fm_rows[[length(fm_rows) + 1L]] <- mk_rows(nm, "test",     pt[[nm]]$Test,
                                             mb = bootres[[nm]]$mb, iid = bootres[[nm]]$iid)
}
fm_rows[[length(fm_rows) + 1L]] <- data.frame(
  model = "BOTH", set = "training_insample", metric = "MASE_denom_consec",
  value = denom_consec, ci_mb_lo = NA_real_, ci_mb_hi = NA_real_,
  ci_iid_lo = NA_real_, ci_iid_hi = NA_real_, paper_value = NA_real_,
  abs_diff_vs_paper = NA_real_,
  note = "PRIMARY MASE denominator: in-sample 1-step persistence MAE, 250 consecutive pairs in series order; identical for both models (same training series)",
  stringsAsFactors = FALSE)
fm_rows[[length(fm_rows) + 1L]] <- data.frame(
  model = "BOTH", set = "training_insample", metric = "MASE_denom_caldays",
  value = denom_caldays, ci_mb_lo = NA_real_, ci_mb_hi = NA_real_,
  ci_iid_lo = NA_real_, ci_iid_hi = NA_real_, paper_value = NA_real_,
  abs_diff_vs_paper = NA_real_,
  note = "ALTERNATIVE MASE denominator: persistence MAE over the 204 calendar-adjacent (1-day) pairs only; identical for both models",
  stringsAsFactors = FALSE)
fm <- do.call(rbind, fm_rows)
fm_path <- file.path(OUT_DIR, paste0("lasso_fullmetrics_", DATE, ".csv"))
write_csv15(fm, fm_path)
cat("Wrote", fm_path, "(", nrow(fm), "rows )\n")
flush(stdout())

# ---------------------------------------------------------------------------
# Assemble file 2: PI + coverage (per-day rows + per-model summary rows)
# ---------------------------------------------------------------------------
pi <- do.call(rbind, c(pi_day, pi_sum))
pi_path <- file.path(OUT_DIR, paste0("lasso_pi_coverage_", DATE, ".csv"))
write_csv15(pi, pi_path)
cat("Wrote", pi_path, "(", nrow(pi), "rows )\n")
flush(stdout())

# ---------------------------------------------------------------------------
# README (method + caveats)
# ---------------------------------------------------------------------------
fmt3 <- function(x) formatC(x, format = "f", digits = 3)
md <- c(
  "# LASSO full metrics + test-set calibration (2026-10-02)",
  "",
  sprintf("Generated: %s", format(Sys.time(), "%Y-%m-%d %H:%M")),
  "",
  "All values computed from the SAVED paper predictions (no re-fitting):",
  "  Compare_models/Graphics/Predicted_values/LASSO_7day_MuSPAD.RData",
  "  Compare_models/Graphics/Predicted_values/LASSO_7day_baseline.RData",
  "Training n = 251 (2020-07-08..2021-07-15, irregular reporting dates);",
  "Test n = 27 (2021-07-16..2021-08-23, one 8-day reporting gap inside the block).",
  "",
  "## Files",
  "",
  paste0("- `lasso_fullmetrics_", DATE, ".csv` (+ .xlsx): point metrics (RMSE, sMAPE 0-2, R2, MAE, MAPE, MASE)\n",
         "  for Training and Test, both models; moving-block and IID bootstrap 95% CIs on the test set;\n",
         "  paper cross-check columns; MASE denominator rows."),
  paste0("- `lasso_pi_coverage_", DATE, ".csv` (+ .xlsx): per-day 95% prediction intervals and coverage\n",
         "  (residual-bootstrap PI + normal-theory PI sensitivity), per-model summary rows with\n",
         "  Clopper-Pearson CIs on coverage."),
  "",
  "## Metric conventions",
  "",
  "- sMAPE on the 0-2 scale: mean(2|a-f|/(|a|+|f|)).",
  "- R2 around the set's own mean. The test window is a quiet post-outbreak period",
  "  (actuals 4.9-23.3), so the test SST is small; test R2 values are reported as computed",
  "  but are not a meaningful ranking statistic for this window.",
  "- MAPE is finite here (all predictions > 0 as exp of a log-scale fit; all actuals > 0).",
  "  The baseline's MAPE is inflated because test actuals are small (median 11.9) while the",
  "  baseline predicts ~67-78.",
  "- MASE denominator (identical for both models, same training series):",
  sprintf("  - PRIMARY: in-sample 1-step persistence MAE over 250 consecutive pairs in series order = %s", fmt3(denom_consec)),
  sprintf("  - ALTERNATIVE: persistence MAE over the 204 calendar-adjacent (1-day) pairs only = %s", fmt3(denom_caldays)),
  "",
  "## Bootstrap CIs (test set)",
  "",
  "- Exact replication of the locked protocol LASSO/LASSO_testset_moving_block_bootstrap.R:",
  "  seed 42, B = 10000, moving-block b = 7 (K = 4 blocks, starts from 1..21) + IID;",
  "  same call order per model (MB then IID) -> resamples bit-identical to the stored",
  "  boot_samples_LASSO_testset.rda (guard G2) and RMSE/sMAPE CIs identical to",
  "  bootstrap_ci_LASSO_testset.csv (guard G3); the new metrics' CIs use the identical resamples.",
  "",
  "## Calibration (test set)",
  "",
  "- LASSO analogue of the VAR innovation-bootstrap PI: pool = 251 in-sample residuals on the",
  "  log scale (models fit on log incidence); the models are non-recursive, so each test day's",
  "  error is a single iid residual draw -> PI width is constant across the 27 days (no",
  "  horizon accumulation, unlike the recursive VAR PI).",
  paste0("- B = ", B_PI, " replicates, seed ", SEED_PI, " (set once before the model loop), type-7 percentiles;\n",
         "  PI reported back-transformed with exp. Sensitivity: normal-theory PI using the pool sd."),
  "- Coverage = fraction of the 27 test days with the actual inside the PI; 95% CI via binom.test",
  "  (Clopper-Pearson). n = 27 per model.",
  "",
  "## Caveats",
  "",
  "- The LASSO fit itself (missForest imputation + CV partition) is stochastic; all quantities",
  "  here refer to the specific saved predictions behind the paper's Tables 1-5, and the",
  "  bootstrap CIs capture only test-observation resampling uncertainty.",
  "- Residual pool = in-sample (training) residuals; the test window is a different regime",
  "  (post-outbreak, small counts), so under-coverage, if present, is expected and mirrors the",
  "  VAR PI finding.",
  "- MASE values are not comparable across models with different training series (project",
  "  convention); within this file the denominator is identical for both models.",
  "")
writeLines(md, file.path(OUT_DIR, paste0("lasso_fullmetrics_pi_README_", DATE, ".md")))
cat("Wrote README\n")

cat("\n================ LASSO full metrics + PI summary ================\n")
print(fm, row.names = FALSE)
cat("\nPer-model PI coverage:\n")
print(pi[pi$level == "summary", c("model", "coverage_n", "coverage_frac", "cp95_lo", "cp95_hi",
                                  "coverage_n_n", "coverage_frac_n", "cp95_lo_n", "cp95_hi_n")],
    row.names = FALSE)
cat("\nDone. Files in:", OUT_DIR, "\n")
