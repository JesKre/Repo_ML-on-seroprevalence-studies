# LASSO full metrics + test-set calibration (2026-10-02)

Generated: 2026-10-02 12:26

All values computed from the SAVED paper predictions (no re-fitting):
  Compare_models/Graphics/Predicted_values/LASSO_7day_MuSPAD.RData
  Compare_models/Graphics/Predicted_values/LASSO_7day_baseline.RData
Training n = 251 (2020-07-08..2021-07-15, irregular reporting dates);
Test n = 27 (2021-07-16..2021-08-23, one 8-day reporting gap inside the block).

## Files

- `lasso_fullmetrics_2026-10-02.csv` (+ .xlsx): point metrics (RMSE, sMAPE 0-2, R2, MAE, MAPE, MASE)
  for Training and Test, both models; moving-block and IID bootstrap 95% CIs on the test set;
  paper cross-check columns; MASE denominator rows.
- `lasso_pi_coverage_2026-10-02.csv` (+ .xlsx): per-day 95% prediction intervals and coverage
  (residual-bootstrap PI + normal-theory PI sensitivity), per-model summary rows with
  Clopper-Pearson CIs on coverage.

## Metric conventions

- sMAPE on the 0-2 scale: mean(2|a-f|/(|a|+|f|)).
- R2 around the set's own mean. The test window is a quiet post-outbreak period
  (actuals 4.9-23.3), so the test SST is small; test R2 values are reported as computed
  but are not a meaningful ranking statistic for this window.
- MAPE is finite here (all predictions > 0 as exp of a log-scale fit; all actuals > 0).
  The baseline's MAPE is inflated because test actuals are small (median 11.9) while the
  baseline predicts ~67-78.
- MASE denominator (identical for both models, same training series):
  - PRIMARY: in-sample 1-step persistence MAE over 250 consecutive pairs in series order = 5.679
  - ALTERNATIVE: persistence MAE over the 204 calendar-adjacent (1-day) pairs only = 4.353

## Bootstrap CIs (test set)

- Exact replication of the locked protocol LASSO/LASSO_testset_moving_block_bootstrap.R:
  seed 42, B = 10000, moving-block b = 7 (K = 4 blocks, starts from 1..21) + IID;
  same call order per model (MB then IID) -> resamples bit-identical to the stored
  boot_samples_LASSO_testset.rda (guard G2) and RMSE/sMAPE CIs identical to
  bootstrap_ci_LASSO_testset.csv (guard G3); the new metrics' CIs use the identical resamples.

## Calibration (test set)

- LASSO analogue of the VAR innovation-bootstrap PI: pool = 251 in-sample residuals on the
  log scale (models fit on log incidence); the models are non-recursive, so each test day's
  error is a single iid residual draw -> PI width is constant across the 27 days (no
  horizon accumulation, unlike the recursive VAR PI).
- B = 2000 replicates, seed 20261025 (set once before the model loop), type-7 percentiles;
  PI reported back-transformed with exp. Sensitivity: normal-theory PI using the pool sd.
- Coverage = fraction of the 27 test days with the actual inside the PI; 95% CI via binom.test
  (Clopper-Pearson). n = 27 per model.

## Caveats

- The LASSO fit itself (missForest imputation + CV partition) is stochastic; all quantities
  here refer to the specific saved predictions behind the paper's Tables 1-5, and the
  bootstrap CIs capture only test-observation resampling uncertainty.
- Residual pool = in-sample (training) residuals; the test window is a different regime
  (post-outbreak, small counts), so under-coverage, if present, is expected and mirrors the
  VAR PI finding.
- MASE values are not comparable across models with different training series (project
  convention); within this file the denominator is identical for both models.

