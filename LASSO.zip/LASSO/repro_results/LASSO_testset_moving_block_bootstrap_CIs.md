# LASSO test-set error: moving-block bootstrap 95% CIs (RMSE, SMAPE)

Generated: 2026-10-01 12:54

Paired (observed, predicted) test values from the saved predictions behind the paper's Tables 1-5
(`Compare_models/Graphics/Predicted_values/LASSO_7day_MuSPAD.RData` and `LASSO_7day_baseline.RData`).
No re-fitting: the CIs refer to the paper's published point estimates.

Test set: n = 27 held-out observations, 2021-07-16 .. 2021-08-23 (nearly consecutive days; one 8-day reporting gap inside the block).

## Method

- Moving-block bootstrap with block length b = 7, matching the 7-day forecasting horizon;
  consecutive days are autocorrelated, so an IID resample understates the uncertainty of the test error.
- Per replicate: K = ceiling(27/7) = 4 blocks; block start positions sampled with replacement from the 21 possible positions; the 28 resampled observations are truncated back to 27.
- B = 10000 replicates; per replicate RMSE and SMAPE recomputed on the resampled (real, predicted) pairs.
- 95% CI = 2.5th / 97.5th percentile of the bootstrap distribution.
- Seed = 42. An IID (single-observation) bootstrap with the same B and seed is included for comparison.

## Results

| model | metric | point estimate | moving-block 95% CI | IID 95% CI (comparison) |
|---|---|---|---|---|
| MuSPAD | RMSE | 9.278 | [5.133, 10.098] | [7.311, 11.142] |
| MuSPAD | SMAPE | 1.068 | [0.864, 1.186] | [0.931, 1.188] |
| onlyTime | RMSE | 61.704 | [60.375, 65.090] | [59.582, 63.511] |
| onlyTime | SMAPE | 1.462 | [1.411, 1.623] | [1.384, 1.538] |

## Consistency checks

- Point estimates reproduce the paper's Tables 3 and 5: MuSPAD RMSE 9.28 / SMAPE 1.07; onlyTime RMSE 61.70 / SMAPE 1.46.
- The moving-block CIs are wider than the IID CIs, as expected when consecutive-day autocorrelation is respected.
- A previous reviewer re-run (w2, `Paper_revision/`) used a day-level IID bootstrap (B = 2000) on a
  seed-42 re-train and obtained MuSPAD RMSE 9.253 [7.353, 11.230]; the IID CIs above (paper predictions,
  B = 10000) are of the same magnitude, and the moving-block CIs are wider.
- The LASSO fit itself (missForest imputation + CV partition) is stochastic, but per specification the
  CIs capture only the uncertainty of the test-observation resampling.

