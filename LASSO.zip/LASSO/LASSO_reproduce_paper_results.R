# ============================================================================
# LASSO_reproduce_paper_results.R
# ----------------------------------------------------------------------------
# Verifies that the LASSO results reported in the paper
# (LOKI_Machine_Learning_for_Infectious_Diseases_251017, Tables 1-5)
# are reproducible by re-running the two original LASSO protocols:
#
#   1) LASSO_model_levelcount_log_scale_all_cities_varsubsetbasic_
#      without_cities_var_imp.R
#      (MuSPAD: log-incidence ~ 121 features, missForest imputation +
#       standardisation with training-set center/scale)
#   2) LASSO_model_only_time_log_all_cities.R
#      (baseline: log-incidence ~ time_day only, raw, no imputation/scaling)
#
# The original scripts set no seed, so missForest imputation and the 10-fold
# cv.glmnet partition are stochastic. This script therefore re-runs each
# protocol on a grid of seeds and compares all five paper metrics
# (MSE, RMSE, MAPE, SMAPE, RMSLE) for training and testing against
#   (a) the paper's Tables 1-5 and
#   (b) the team's saved CSVs (mse_LASSO_MuSPAD.csv / mse_LASSO_onlyTime.csv).
#
# No file of the original runs is overwritten. All outputs are written to
#   LASSO/repro_results/
# ============================================================================

suppressMessages({
  library(glmnet)
  library(missForest)
  library(Metrics)
})

# --- paths --------------------------------------------------------------------
DATA_FILE <- "S:/PROJACTIVE/MUSPAD-LABORERGEBNISSE/LOKI_ML/Datasets/Time_series_data_incidence_1W_binary_classnumber_var_subset_missing_zero_2025-02-14.RData"
LASSO_DIR <- "S:/PROJACTIVE/MUSPAD-LABORERGEBNISSE/LOKI_ML/muspad-ml-loki-sp2.1/LASSO"
PV_DIR    <- "S:/PROJACTIVE/MUSPAD-LABORERGEBNISSE/LOKI_ML/muspad-ml-loki-sp2.1/Compare_models/Graphics/Predicted_values"
OUT_DIR   <- file.path(LASSO_DIR, "repro_results")
dir.create(OUT_DIR, showWarnings = FALSE, recursive = TRUE)

SEEDS      <- 1:10
CANON_SEED <- 42

# --- values reported in the paper (251017, Tables 1-5) ------------------------
paper <- data.frame(
  model  = c(rep("MuSPAD", 5), rep("onlyTime", 5)),
  metric = rep(c("MSE", "RMSE", "MAPE", "SMAPE", "RMSLE"), 2),
  train  = c(1093.07, 33.09, 0.45, 0.39, 0.46,
             5002.61, 70.73, 2.42, 0.91, 1.24),
  test   = c(86.08, 9.28, 0.68, 1.07, 1.09,
             3807.41, 61.70, 6.56, 1.46, 1.89),
  stringsAsFactors = FALSE)

# --- MSE values saved by the team in the LASSO folder (01./02.09.2025) --------
team_saved <- data.frame(
  model     = c("MuSPAD", "onlyTime"),
  mse_train = c(1094.98270368485, 5002.60547372449),
  mse_test  = c(86.0885952257233, 3807.41267802677),
  stringsAsFactors = FALSE)

# --- load + prepare the data exactly as the original scripts do ---------------
load_prepped_data <- function() {
  env <- new.env()
  load(DATA_FILE, envir = env)
  d <- env[["df_ts_inc"]]
  d[["time_day"]] <- as.numeric(d[["time_day"]])
  d <- d[-which(d[["time_day"]] == "168"), ]
  d[, 1] <- log(d[, 1])
  d
}

# --- the five metrics of the paper's tables (Metrics package, exp scale) ------
metrics5 <- function(real, pred) {
  c(MSE   = mse(real, pred),
    RMSE  = rmse(real, pred),
    MAPE  = mape(real, pred),
    SMAPE = smape(real, pred),
    RMSLE = rmsle(real, pred))
}

# --- split, verbatim from the original scripts --------------------------------
# n = 279. With the double endpoints of the original code, R's `:` gives
#   1:(279/10*9)     = 1:251.1   -> rows 1..251   (251 obs)
#   (279/10*9+1):279 = 252.1:279 -> rows 252..278 (27 obs); row 279 unused
make_split <- function(n) {
  list(train = 1:(n / 10 * 9), test = (n / 10 * 9 + 1):n)
}

to_date <- function(d, ix) as.Date("2020-01-01") + d[ix, "time_day"] + 7

# --- protocol 1: MuSPAD LASSO (faithful to the original script) ---------------
fit_muspad <- function(seed = NULL) {
  if (!is.null(seed)) set.seed(seed)
  d  <- load_prepped_data()
  sp <- make_split(nrow(d))

  traindat_1     <- missForest(d[sp$train, -1])$ximp
  traindat_scale <- scale(traindat_1)
  traindat       <- as.data.frame(traindat_scale)
  traindat_y     <- d[sp$train, 1]

  testdat_1 <- missForest(d[sp$test, -1])$ximp
  testdat_scale <- scale(testdat_1,
                         center = attr(traindat_scale, "scaled:center"),
                         scale  = attr(traindat_scale, "scaled:scale"))
  testdat    <- as.data.frame(testdat_scale)
  testdat_y  <- d[sp$test, 1]

  lambda_seq <- 10 ^ seq(2, -2, by = -.1)
  cv_out <- cv.glmnet(x = as.matrix(traindat), y = traindat_y,
                      alpha = 1, lambda = lambda_seq, nfolds = 10)
  best_lam <- cv_out$lambda.min
  model    <- glmnet(traindat, traindat_y, alpha = 1, lambda = best_lam)

  list(
    lambda = best_lam,
    nz_coefs = length(coef(model)@x),
    coefs = coef(model),
    train_real = exp(traindat_y),
    train_pred = as.numeric(exp(predict(model, newx = as.matrix(traindat)))),
    test_real  = exp(testdat_y),
    test_pred  = as.numeric(exp(predict(model, newx = as.matrix(testdat)))),
    train_time = to_date(d, sp$train),
    test_time  = to_date(d, sp$test))
}

# --- protocol 2: time-only baseline (faithful to the original script) ---------
fit_ontime <- function(seed = NULL) {
  if (!is.null(seed)) set.seed(seed)
  d  <- load_prepped_data()
  sp <- make_split(nrow(d))

  predictor  <- as.data.frame(cbind(0, d[, 2]))
  traindat   <- predictor[sp$train, ]
  traindat_y <- d[sp$train, 1]
  testdat    <- predictor[sp$test, ]
  testdat_y  <- d[sp$test, 1]

  lambda_seq <- 10 ^ seq(3, -3, by = -.1)
  cv_out <- cv.glmnet(x = as.matrix(traindat), y = traindat_y,
                      alpha = 1, lambda = lambda_seq, nfolds = 10)
  best_lam <- cv_out$lambda.min
  model    <- glmnet(traindat, traindat_y, alpha = 1, lambda = best_lam)

  list(
    lambda = best_lam,
    nz_coefs = length(coef(model)@x),
    coefs = coef(model),
    train_real = exp(traindat_y),
    train_pred = as.numeric(exp(predict(model, newx = as.matrix(traindat)))),
    test_real  = exp(testdat_y),
    test_pred  = as.numeric(exp(predict(model, newx = as.matrix(testdat)))),
    train_time = to_date(d, sp$train),
    test_time  = to_date(d, sp$test))
}

# --- seed sweep -----------------------------------------------------------------
run_sweep <- function(model_name, fit_fn) {
  fits <- vector("list", length(SEEDS))
  names(fits) <- as.character(SEEDS)
  for (s in SEEDS) {
    fits[[as.character(s)]] <- fit_fn(seed = s)
    message(sprintf("  [%s] seed %2d done (lambda.min = %.5f, %d nonzero coefs)",
                    model_name, s, fits[[as.character(s)]]$lambda,
                    fits[[as.character(s)]]$nz_coefs))
  }
  df <- do.call(rbind, lapply(names(fits), function(s) {
    f   <- fits[[s]]
    mtr <- metrics5(f$train_real, f$train_pred)
    mte <- metrics5(f$test_real, f$test_pred)
    data.frame(model = model_name, seed = as.integer(s),
               lambda_min = f$lambda, nz_coefs = f$nz_coefs,
               mse_train   = mtr["MSE"],   rmse_train   = mtr["RMSE"],
               mape_train  = mtr["MAPE"],  smape_train  = mtr["SMAPE"],
               rmsle_train = mtr["RMSLE"],
               mse_test    = mte["MSE"],   rmse_test    = mte["RMSE"],
               mape_test   = mte["MAPE"],  smape_test   = mte["SMAPE"],
               rmsle_test  = mte["RMSLE"],
               stringsAsFactors = FALSE)
  }))
  message(sprintf("[%s] sweep: MSE test %.3f..%.3f | RMSE test %.3f..%.3f | SMAPE test %.3f..%.3f",
                  model_name, min(df$mse_test), max(df$mse_test),
                  min(df$rmse_test), max(df$rmse_test),
                  min(df$smape_test), max(df$smape_test)))
  list(fits = fits, df = df)
}

message("=== Re-running MuSPAD LASSO protocol (seeds ", paste(SEEDS, collapse = ", "), ") ===")
sw_muspad <- run_sweep("MuSPAD", fit_muspad)
message("=== Re-running time-only baseline protocol (seeds ", paste(SEEDS, collapse = ", "), ") ===")
sw_ontime <- run_sweep("onlyTime", fit_ontime)

sweep_df <- rbind(sw_muspad$df, sw_ontime$df)
write.csv(sweep_df, file.path(OUT_DIR, "seed_sweep_LASSO_all_seeds.csv"), row.names = FALSE)

# --- save canonical-seed paired predictions -------------------------------------
save_pairs <- function(model_name, fit) {
  df <- rbind(
    data.frame(time = fit$train_time, real = fit$train_real,
               predicted = fit$train_pred, set = "Training"),
    data.frame(time = fit$test_time, real = fit$test_real,
               predicted = fit$test_pred, set = "Test"))
  f <- file.path(OUT_DIR, sprintf("real_vs_pred_%s_seed%d.csv", model_name, CANON_SEED))
  write.csv(df, f, row.names = FALSE)
  message("saved ", f)
}
# --- canonical fits (seed 42), separate from the 10-seed sweep ------------------
message("=== Fitting canonical models (seed ", CANON_SEED, ") for prediction export ===")
canon <- list(MuSPAD = fit_muspad(seed = CANON_SEED),
              onlyTime = fit_ontime(seed = CANON_SEED))

save_pairs("MuSPAD", canon$MuSPAD)
save_pairs("onlyTime", canon$onlyTime)

# --- test pairs from the saved predictions behind the paper tables -------------
paper_test_pairs <- function(fname, obj) {
  env <- new.env()
  load(file.path(PV_DIR, fname), envir = env)
  d <- env[[obj]]
  x <- d[d[["set"]] == "Test", ]
  r <- x[x[["real_vs_pred"]] == "real", c("time", "Incidence")]
  p <- x[x[["real_vs_pred"]] == "predicted", c("time", "Incidence")]
  names(r)[2] <- "real"
  names(p)[2] <- "predicted"
  m <- merge(r, p, by = "time")
  m[order(m$time), , drop = FALSE]
}

crosscheck_predictions <- function(model_name, fit) {
  paper_pairs <- paper_test_pairs(
    if (model_name == "MuSPAD") "LASSO_7day_MuSPAD.RData" else "LASSO_7day_baseline.RData",
    if (model_name == "MuSPAD") "graph_LASSO_7day_M" else "graph_LASSO_7day_BL")
  mine <- data.frame(time = fit$test_time, real = fit$test_real,
                     predicted = fit$test_pred)
  j <- merge(paper_pairs, mine, by = "time", suffixes = c("_paper", "_retrain"))
  c(n = nrow(j),
    max_abs_diff_real  = max(abs(j$real_paper - j$real_retrain)),
    max_abs_diff_pred  = max(abs(j$predicted_paper - j$predicted_retrain)),
    mean_rel_diff_pred = mean(abs(j$predicted_paper - j$predicted_retrain) /
                                j$predicted_paper))
}
cc_m <- crosscheck_predictions("MuSPAD", canon$MuSPAD)
cc_o <- crosscheck_predictions("onlyTime", canon$onlyTime)

# --- variable selection vs the saved variable list -------------------------------
compare_varlist <- function(fit) {
  vl_files <- list.files(LASSO_DIR,
                         pattern = "^Variablelist_LASSO_varsubsetbasic_.*\\.RData$")
  if (length(vl_files) == 0) return(NULL)
  vl_file <- tail(sort(vl_files), 1)
  env <- new.env()
  load(file.path(LASSO_DIR, vl_file), envir = env)
  saved <- env[["var_list_ordered"]]
  cf        <- as.matrix(fit$coefs)
  mine_vars <- rownames(cf)[cf[1, ] != 0]
  saved_vars <- saved$Var[saved$Var != "intercept"]
  list(saved_file = vl_file,
       n_saved = length(saved_vars),
       n_retrain = length(mine_vars) - 1,
       overlap = length(intersect(mine_vars, saved_vars)))
}
vl <- compare_varlist(canon$MuSPAD)

# --- summary: paper values vs re-train seed range --------------------------------
metric_cols <- list(MSE   = c("mse_train",   "mse_test"),
                    RMSE  = c("rmse_train",  "rmse_test"),
                    MAPE  = c("mape_train",  "mape_test"),
                    SMAPE = c("smape_train", "smape_test"),
                    RMSLE = c("rmsle_train", "rmsle_test"))

repro_summary <- do.call(rbind, lapply(split(paper, paper$model), function(p) {
  m   <- p$model[1]
  sub <- sweep_df[sweep_df$model == m, ]
  do.call(rbind, lapply(seq_len(nrow(p)), function(i) {
    met    <- p$metric[i]
    tr_col <- metric_cols[[met]][1]
    te_col <- metric_cols[[met]][2]
    bs     <- which.min(abs(sub[[te_col]] - p$test[i]))
    data.frame(model = m, metric = met,
               paper_train = p$train[i], paper_test = p$test[i],
               retrain_train_range = sprintf("%.4g..%.4g", min(sub[[tr_col]]), max(sub[[tr_col]])),
               retrain_test_range  = sprintf("%.4g..%.4g", min(sub[[te_col]]), max(sub[[te_col]])),
               paper_test_in_retrain_range =
                 ifelse(p$test[i] >= min(sub[[te_col]]) && p$test[i] <= max(sub[[te_col]]),
                        "yes", "no"),
               best_seed          = sub$seed[bs],
               retrain_best_train = sub[[tr_col]][bs],
               retrain_best_test  = sub[[te_col]][bs],
               stringsAsFactors = FALSE)
  }))
}))

team_check <- do.call(rbind, lapply(split(team_saved, team_saved$model), function(t) {
  m    <- t$model[1]
  sub  <- sweep_df[sweep_df$model == m, ]
  i_tr <- which.min(abs(sub$mse_train - t$mse_train[1]))
  i_te <- which.min(abs(sub$mse_test - t$mse_test[1]))
  data.frame(model = m,
             team_mse_train = t$mse_train[1], team_mse_test = t$mse_test[1],
             retrain_mse_train_range = sprintf("%.4g..%.4g", min(sub$mse_train), max(sub$mse_train)),
             retrain_mse_test_range  = sprintf("%.4g..%.4g", min(sub$mse_test), max(sub$mse_test)),
             closest_seed_train = sub$seed[i_tr],
             diff_mse_train = abs(sub$mse_train[i_tr] - t$mse_train[1]),
             closest_seed_test = sub$seed[i_te],
             diff_mse_test  = abs(sub$mse_test[i_te] - t$mse_test[1]))
}))

write.csv(repro_summary, file.path(OUT_DIR, "repro_summary_vs_paper.csv"), row.names = FALSE)
write.csv(team_check,    file.path(OUT_DIR, "repro_summary_vs_team_csv.csv"), row.names = FALSE)

# --- console report ----------------------------------------------------------------
cat("\n================ LASSO paper reproducibility check ================\n\n")
cat("Split (n=279): training rows 1:251 (251 obs), test rows 252:278 (27 obs), row 279 unused\n")
cat("Test block: 2021-07-16 .. 2021-08-23\n\n")
cat("Paper tables vs 10-seed re-train (range over seeds; best seed = closest to paper test value):\n")
print(repro_summary, row.names = FALSE)
cat("\nTeam-saved MSE CSVs vs 10-seed re-train:\n")
print(team_check, row.names = FALSE)
cat("\nCanonical-seed (42) test predictions vs the saved predictions behind the paper:\n")
cat(sprintf("  MuSPAD:   n=%d  max|d real|=%.6f  max|d pred|=%.4f  mean rel|d pred|=%.4f\n",
            cc_m["n"], cc_m["max_abs_diff_real"], cc_m["max_abs_diff_pred"], cc_m["mean_rel_diff_pred"]))
cat(sprintf("  onlyTime: n=%d  max|d real|=%.6f  max|d pred|=%.4f  mean rel|d pred|=%.4f\n",
            cc_o["n"], cc_o["max_abs_diff_real"], cc_o["max_abs_diff_pred"], cc_o["mean_rel_diff_pred"]))
if (!is.null(vl)) {
  cat(sprintf("\nVariable selection (seed %d vs saved list %s): %d retrain / %d saved nonzero vars, overlap %d\n",
              CANON_SEED, vl$saved_file, vl$n_retrain, vl$n_saved, vl$overlap))
}
cat("\nFiles written to:", OUT_DIR, "\n")
